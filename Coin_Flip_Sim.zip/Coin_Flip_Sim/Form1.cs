﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coin_Flip_Sim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int amountOfFlips = Convert.ToInt32(amnt_flips.Text);
            int headCount = 0;
            int tailCount = 0;

            Random rnd = new Random();

            Enumerable.Range(1, amountOfFlips)
                .Select(flip => rnd.Next(2))
                .ToList()
                .ForEach(flipResult =>
                {
                    if(flipResult == 1)
                    {
                        headCount++;
                    }
                    else
                    {
                        tailCount++;
                    }
                });

            while (amountOfFlips > 0)
            {
                int coin = rnd.Next(2);
                if (coin == 1)
                {
                    headCount++;
                }
                else
                {
                    tailCount++;
                }

                amountOfFlips--;
            }

            tails_count.Text = tailCount++.ToString();
            heads_count.Text = headCount++.ToString();
        }

        private void amnt_flips_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
